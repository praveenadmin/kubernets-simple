Execute this shell script on ubuntu machine as a root user
syntax: ./install.sh <userName>
example ./install.sh ubuntu
The above example assumes the username is ubuntu